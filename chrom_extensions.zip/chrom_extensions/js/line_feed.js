document.addEventListener('paste', function (e) {
	
	var copy_content = e.clipboardData.getData('text/plain').replace(/[\n\r]/g,' ');
	
	// alert(copy_content);
	
	document.onkeydown = function (e) {
		if ( e.ctrlKey && e.keyCode == 86) {//ctrl+V
				// This is necessary to prevent the default paste action.
	
				
				document.execCommand("insertHTML", false, copy_content);
				document.execCommand("insertLineBreak", false);
				document.execCommand("insertLineBreak", false);
			// function handler(event) {
				// document.removeEventListener('copy', handler, true);				
				// event.stopImmediatePropagation();		
				// event.preventDefault();
				// event.clipboardData.setData('text/plain', copy_content);

			// }
			
			// document.addEventListener('copy', handler, true);
			// document.execCommand('copy');			 
		}
	}

	
	// e.stopImmediatePropagation();
	// e.preventDefault();
	// e.preventDefault();		
	
	
	 
});
 