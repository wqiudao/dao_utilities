# Python 3.7.5
import re,sys,gzip

dic_inputCollapse={}
dic_inputCollapse_details={}
isolation_item=1;


if len(sys.argv)!=2:
	print("python "+sys.argv[0]+" input_fields.flat")
	sys.exit(0)

input_fields=sys.argv[1]
opfname=re.sub(r'[\.\_]+[a-zA-Z0-9]+$','_Collapse.tsv',input_fields);opfname =open(opfname,"w")
input_file =open(input_fields)
reads=input_file.readline()
while reads:
	inputCollapse=re.sub(r'[\r\n]+','',reads)
	inputCollapseSet=inputCollapse.split("\t")
	
	if inputCollapseSet[0] in dic_inputCollapse_details:
		dic_inputCollapse_details[inputCollapseSet[0]]=dic_inputCollapse_details[inputCollapseSet[0]]+";"+"|".join(inputCollapseSet)
		dic_inputCollapse[inputCollapseSet[0]]=dic_inputCollapse[inputCollapseSet[0]]+"|"+inputCollapseSet[isolation_item]
	else:	
		dic_inputCollapse_details[inputCollapseSet[0]]="|".join(inputCollapseSet)
		dic_inputCollapse[inputCollapseSet[0]]=inputCollapseSet[isolation_item]
	# print(inputCollapseSet[0])
	# print(dic_inputCollapse[inputCollapseSet[0]])
	# print(dic_inputCollapse_details[inputCollapseSet[0]])
	reads=input_file. readline()
input_file.close()


for key_item in dic_inputCollapse:
	# print(key_item)
	opfname.write(key_item+"\t"+dic_inputCollapse[key_item]+"\t"+dic_inputCollapse_details[key_item]+"\n")



opfname.close()