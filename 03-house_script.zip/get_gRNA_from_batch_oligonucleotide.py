# get_gRNA_from_batch_oligonucleotide
# 从 gRNA 的batch序列，提取出grna，特征是，grna两侧的序列是固定的
# preAnchor gRNA postAnchor
# 结果扩展名改成xls，因为tsv，Excel 2016 无法默认打开

import sys,re	
if len(sys.argv)<2:
	print("python "+sys.argv[0]+" batch_oligonucleotide.flat")
	sys.exit(0)

preAnchor = "GGAAAGGACGAAACACCG"
postAnchor = "GTTTTAGAGCTAGAAATAGCAAGTTAAAATAAGGC"

seqFname=sys.argv[1]
input_file =open(seqFname)
opfname=re.sub(r'[\.\_]+[a-zA-Z0-9]+$','_gRNA_features.xls',seqFname);
sgRNA_library_file_MAGeCK=re.sub(r'[\.\_]+[a-zA-Z0-9]+$','_sgRNA_library_MAGeCK.xls',seqFname);
ofh =open(opfname,"w")
ofhm =open(sgRNA_library_file_MAGeCK,"w")
reads=input_file. readline()
sgrna_count=0;
while reads:
	sgrna_count+=1;
	reads=re.sub(r'[\r\n]+','',reads)
	readset=re.split(r'\t+',reads)
	# print(readset[2])
	ofh.write(readset[1]+"\t")
	matchObj = re.search( r"("+preAnchor+")([ATCG]+"+")("+ postAnchor+')', readset[2], re.I)
	if matchObj:
		# print(matchObj.group(2))
		ofh.write(matchObj.group(2)+"\t")
		ofhm.write("s_"+readset[0]+'_'+str(sgrna_count)+"\t")
		ofhm.write(matchObj.group(2)+"\t")
		readset[1]=re.sub(r'[\W\_]+','',readset[1])
		# readset[1]=re.sub(r'^[\r\n\s\)\(]+','',readset[1])
		# readset[1]=re.sub(r'[\r\n\s\)\(]+','_',readset[1])
		ofhm.write(readset[1]+"\n")
	else:
		ofh.write("NA\t")
	ofh.write(readset[0]+"\t"+readset[2]+"\n")
	reads=input_file. readline()
ofhm.close()	
ofh.close()	
input_file.close()

